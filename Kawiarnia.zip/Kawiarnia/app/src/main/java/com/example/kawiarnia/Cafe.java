package com.example.kawiarnia;

import androidx.annotation.DrawableRes;

public class Cafe {
    private String name;
    private String address;
    private String openingHours;
    @DrawableRes
    private int mapImageResourceId;

    public static final Cafe cafe = new Cafe(
        "Kawiarnia Kafette",
        "ul. Kawowa 15, 00-123 Czestochowa",
        "Pon-Pt: 7:00-20:00\nSob-Nd: 8:00-19:00",
        R.drawable.cafe_map
    );

    public Cafe(String name, String address, String openingHours, @DrawableRes int mapImageResourceId) {
        this.name = name;
        this.address = address;
        this.openingHours = openingHours;
        this.mapImageResourceId = mapImageResourceId;
    }

    public String getName() { return name; }
    public String getAddress() { return address; }
    public String getOpeningHours() { return openingHours; }
    public @DrawableRes int getMapImageResourceId() { return mapImageResourceId; }
}