package com.example.cafe;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.ImageView;
import com.example.kawiarnia.R;

public class CafeActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cafe);

        TextView name = (TextView)findViewById(R.id.cafe_name);
        name.setText(Cafe.cafe.getName());

        TextView address = (TextView)findViewById(R.id.cafe_address);
        address.setText(Cafe.cafe.getAddress());

        TextView hours = (TextView)findViewById(R.id.cafe_hours);
        hours.setText(Cafe.cafe.getOpeningHours());

        ImageView map = (ImageView)findViewById(R.id.cafe_map);
        map.setImageResource(Cafe.cafe.getMapImageResourceId());
        map.setContentDescription("Mapa lokalizacji " + Cafe.cafe.getName());
    }
}
