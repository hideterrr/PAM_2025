package com.example.cafe;

import com.example.kawiarnia.R;

public class Drink {
    private String name;
    private String description;
    private double price;
    private int imageResourceId;

    public static final Drink[] drinks = {
        new Drink("Latte", "Kawa z mlekiem i delikatną pianką", 12.99, R.drawable.latte),
        new Drink("Cappuccino", "Klasyczne włoskie cappuccino", 11.99, R.drawable.cappuccino),
        new Drink("Espresso", "Mocne espresso", 8.99, R.drawable.espresso)
    };

    public Drink(String name, String description, double price, int imageResourceId) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageResourceId = imageResourceId;
    }

    // Gettery
    public String getName() { return name; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public int getImageResourceId() { return imageResourceId; }

    @Override
    public String toString() {
        return name;
    }
}