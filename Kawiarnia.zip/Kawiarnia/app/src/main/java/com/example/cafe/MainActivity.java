package com.example.cafe;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import com.example.kawiarnia.R;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> listView, View v, int position, long id) {
                switch(position) {
                    case 0: // Napoje
                        Intent drinkIntent = new Intent(MainActivity.this, DrinkCategoryActivity.class);
                        startActivity(drinkIntent);
                        break;
                    case 1: // Przekąski
                        Intent snackIntent = new Intent(MainActivity.this, SnackCategoryActivity.class);
                        startActivity(snackIntent);
                        break;
                    case 2: // Lokalizacja
                        Intent cafeIntent = new Intent(MainActivity.this, CafeActivity.class);
                        startActivity(cafeIntent);
                        break;
                }
            }
        };

        ListView listView = (ListView) findViewById(R.id.list_options);
        listView.setOnItemClickListener(itemClickListener);
    }
}