package com.example.cafe;

import com.example.kawiarnia.R;

public class Snack {
    private String name;
    private String description;
    private double price;
    private int imageResourceId;

    public static final Snack[] snacks = {
        new Snack("Croissant", "Maślany croissant", 8.99, R.drawable.croissant),
        new Snack("Muffin", "Muffin z kawałkami czekolady", 7.99, R.drawable.muffin),
        new Snack("Sernik", "Domowy sernik", 13.99, R.drawable.cheesecake)
    };

    public Snack(String name, String description, double price, int imageResourceId) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageResourceId = imageResourceId;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public int getImageResourceId() { return imageResourceId; }
    
    @Override
    public String toString() {
        return name;
    }
}