package com.example.kawiarnia;

public class Drink {
    private String name;
    private String description;
    private double price;
    private int imageResourceId;

    public static final Drink[] drinks = {
        new Drink("Espresso", "Klasyczne włoskie espresso", 9.99, R.drawable.espresso),
        new Drink("Cappuccino", "Kawa z mleczną pianką", 12.99, R.drawable.cappuccino),
        new Drink("Latte", "Kawa z dużą ilością mleka", 13.99, R.drawable.latte),
        new Drink("Mocha", "Kawa z dodatkiem czekolady", 14.99, R.drawable.mocha)
    };

    public Drink(String name, String description, double price, int imageResourceId) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageResourceId = imageResourceId;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public int getImageResourceId() { return imageResourceId; }

    @Override
    public String toString() {
        return name;
    }
} 