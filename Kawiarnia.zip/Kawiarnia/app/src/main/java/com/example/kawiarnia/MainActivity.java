package com.example.kawiarnia;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.cafe.CafeActivity;
import com.example.cafe.DrinkCategoryActivity;
import com.example.cafe.SnackCategoryActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Utworzenie adaptera dla listy głównej
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
            this,
            R.array.options,
            android.R.layout.simple_list_item_1
        );

        ListView listView = findViewById(R.id.list_options);
        listView.setAdapter(adapter);

        // Obsługa kliknięć
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0: // Napoje
                        Intent drinkIntent = new Intent(MainActivity.this, DrinkCategoryActivity.class);
                        startActivity(drinkIntent);
                        break;
                    case 1: // Przekąski
                        Intent snackIntent = new Intent(MainActivity.this, SnackCategoryActivity.class);
                        startActivity(snackIntent);
                        break;
                    case 2: // Informacje o lokalu
                        Intent cafeIntent = new Intent(MainActivity.this, CafeActivity.class);
                        startActivity(cafeIntent);
                        break;
                }
            }
        });
    }
}