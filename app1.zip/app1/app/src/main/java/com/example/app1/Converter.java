package com.example.app1;

import androidx.appcompat.app.AppCompatActivity;

import java.text.CharacterIterator;
import java.text.StringCharacterIterator;

public class Converter extends AppCompatActivity {
    private static final int[] VALUES =
            {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
    private static final String[] SYMBOLS =
            {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};

    public static String convertToRoman(String arabicNumber) {
        int number;
        try {
            number = Integer.parseInt(arabicNumber);
        } catch (NumberFormatException e) {
            return "";
        }

        if (number > 3999) {
            return "Number has to be in range 1-3999.";
        }

        if (number == 0) {
            return "";
        }

        StringBuilder roman = new StringBuilder();
        for (int i = 0; i < VALUES.length; i++) {
            while (number >= VALUES[i]) {
                roman.append(SYMBOLS[i]);
                number -= VALUES[i];
            }
        }
        return roman.toString();
    }
    public static String convertToArabic(String roman) {
        if (roman == null || roman.isEmpty()) {
            return "";
        }

        int result = 0;
        int repeats = 0;
        CharacterIterator it = new StringCharacterIterator(roman);

        while (it.current() != CharacterIterator.DONE) {
            if (repeats == 3) {
                return "Invalid input: incorrect number";
            }
            String symbol = String.valueOf(it.current());
            String nextSymbol = String.valueOf(it.next());
            for (int i = 0; i < SYMBOLS.length; i++) {
                if (symbol.equals(SYMBOLS[i])) {
                    result += VALUES[i];
                }
            }
            if (it.current() == it.next()) {
                repeats++;
            }
        }

        return Integer.toString(result);
    }
}


// 1921 = MCMXXI